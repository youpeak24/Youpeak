# YouPeak Premium Asset Pack

This archive contains 337 asset files, covering the 328 original asset filenames plus generated additional controls and declared-path aliases. Provenance is recorded in manifest.csv and manifest.json.

Status counts: {"newly generated": 44, "generation pending or failed \u2014 original retained": 268, "preserved existing": 24, "derived from newly generated master": 1}

## Contents
- assets/icons: app-sized image exports, preserving existing filenames.
- generated-masters: full-resolution new image-generation outputs.
- additional-controls: dedicated new controls from the prompt guide; these need code references when adopted.
- previews: labeled contact sheets for visual review.
- prompts: complete source prompts and inventory.

## Use
Review the contact sheets first. Back up assets before selectively copying replacements into your Flutter project. This package does not modify app code. Most UI glyphs are black alpha images intended for the existing runtime color tint. Full-color illustrations should not receive that tint. Official provider logos, approved YouPeak brand assets and mic.json are preserved existing files, not newly generated images. The manifest makes this distinction explicit.

These are raster images, not hand-cleaned SVGs. Check at real display sizes before release, especially badges, player controls, text-like glyphs and Android launcher/notification assets. Existing brand/system assets are retained to preserve your identity and platform-specific behavior. This archive is an asset deliverable, not a verified application build. Any missing or failed generation is clearly labeled and retains the old file instead of silently disappearing.
